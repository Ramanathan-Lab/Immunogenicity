import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { Box, Card, CardContent, Button, Typography, CircularProgress } from '@mui/material';
import axios from 'axios';

export default function DetailsPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const [record, setRecord] = useState(null);
  const [loading, setLoading] = useState(true);

  const productid = location.state?.productid;
  const ndcpackagecode = location.state?.ndcpackagecode;
  const filters = location.state?.filters || {};
  const fieldsOrder = location.state?.fieldsOrder || [];

  useEffect(() => {
    if (!productid && !ndcpackagecode) {
      console.error("No productid or ndcpackagecode received in DetailsPage.");
      setLoading(false);
      return;
    }
    fetchRecordDetails();
  }, [productid, ndcpackagecode]);

  const fetchRecordDetails = async () => {
    try {
      console.log("Fetching details for:", productid || ndcpackagecode);
      const response = await axios.get(`http://localhost:5000/api/get-details`, {
        params: { productid, ndcpackagecode }
      });

      console.log("Full record received:", response.data);
      setRecord(response.data);
    } catch (err) {
      console.error("Error fetching details:", err);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!record) {
    return (
      <div>
        <Navbar />
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', flexDirection: 'column' }}>
          <Typography variant="h5">No record selected. Please go back to the results page.</Typography>
          <Button variant="contained" sx={{ marginTop: 2 }} onClick={() => navigate('/results', { state: { filters, fieldsOrder } })}>
            Back to Results
          </Button>
        </Box>
      </div>
    );
  }

  return (
    <div>
      <Navbar />
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <Card sx={{ width: '60%', padding: 3 }}>
          <CardContent>
            <Typography variant="h4" sx={{ textAlign: 'center', marginBottom: 2 }}>Record Details</Typography>
            {Object.keys(record).map((section) => (
              <div key={section} style={{ marginBottom: 20 }}>
                <Typography variant="h6" sx={{ textAlign: 'center', marginBottom: 1 }}>{section.toUpperCase()}</Typography>
                {Object.keys(record[section] || {}).map((key) => (
                  <Typography key={key} sx={{ textAlign: 'center' }}>
                    <strong>{key}:</strong> {record[section][key] ? record[section][key].toString() : "N/A"}
                  </Typography>
                ))}
              </div>
            ))}
            <Box sx={{ display: 'flex', justifyContent: 'center', marginTop: 2 }}>
              <Button variant="contained" sx={{ marginRight: 2 }} onClick={() => navigate('/results', { state: { filters, fieldsOrder } })}>
                Back to Results
              </Button>
            </Box>
          </CardContent>
        </Card>
      </Box>
    </div>
  );
}
